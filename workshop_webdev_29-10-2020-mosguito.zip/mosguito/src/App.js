import { useState } from 'react'
import YAML from 'yaml'
import {
  Card,
  CardContent,
  CardActions,
  TextField,
  Select,
  MenuItem,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button
} from '@material-ui/core'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'
import Concertin from './components/Concertin'
import { defaultValues } from './utils/defaultValues'
import { assemblerOptions } from './utils/options'
import './App.css'

// README

// setup https://reactjs.org/docs/create-a-new-react-app.html
// COMPONENTS LIBRARY https://material-ui.com/
// NEW PACKAGES www.npmjs.com
// MORE ABOUT REACT www.reactjs.org

const Main = () => {
  const [useAssembler, setUseAssembler] = useState(false)
  const [values, setValues] = useState(defaultValues)

  const handleChange = (field, value) => {
    const newValue = { ...values, [field]: value }
    setValues(newValue)
  }

  const boxes = [
    {
      checked: values.downloadUniprot,
      field: 'downloadUniprot',
      label: 'download uniprot'
    },
    {
      checked: values.check,
      field: 'check',
      label: 'bacon'
    }
  ]
  
  const handleSubmit = (ev) => {
    ev.preventDefault()
     
    console.log(JSON.stringify(values, null, 2))
    console.log(YAML.stringify(values))
  }

  return (
    <main className='main'>
      <form className='form' onSubmit={handleSubmit}>
        <Card>
          <CardContent>
            <TextField
              type='text'
              label='output'
              fullWidth
              value={values.output}
              onChange={(ev) => handleChange('output', ev.target.value)}
            />

            <TextField
              type='number'
              label='threads'
              fullWidth
              value={values.threads}
              onChange={(ev) => handleChange('threads', Number(ev.target.value))}
            />

            <Accordion
              expanded={useAssembler}
              onChange={(_, value) => setUseAssembler(value)}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
              >
                Assembler
              </AccordionSummary>
              <AccordionDetails>
                <Select
                  value={values.assembler}
                  onChange={(ev) => handleChange('assembler', ev.target.value)}
                >
                  {
                    assemblerOptions.map((option) => {
                      return (
                        <MenuItem
                          key={option}
                          value={option}
                        >
                          {option}
                        </MenuItem>
                      )
                    })
                  }
                </Select>
              </AccordionDetails>
            </Accordion>

            {
              boxes.map((box, index) => {
                return (
                  <Concertin 
                    key={index}
                    checked={box.checked}
                    setChecked={(ev) => handleChange(box.field, ev.target.checked)}
                    label={box.label}
                  />
                )
              })
            }
            
          </CardContent>
          <CardActions
            style={{
              display: 'flex',
              justifyContent: 'flex-end'
            }}
          >
            <Button
              type='submit'
              variant='contained'
              color='secondary'
            >
              Save me plox
            </Button>
          </CardActions>
        </Card>
      </form>
    </main>
  )
}

const Header = () => {
  return (
    <header className='header'>
      <h1>
        Mosguito
      </h1>
      <a href='ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/uniprot_sprot.fasta.gz' >
        <span style={{ color: 'wheat' }}>fasta for free</span>
      </a>
    </header>
  )
}

function App() {
  return (
    <div className='App'>
      <Header />
      <Main />
    </div>
  )
}

export default App
