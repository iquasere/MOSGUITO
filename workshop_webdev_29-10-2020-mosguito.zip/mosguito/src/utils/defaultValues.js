import { assemblerOptions } from './options'

export const defaultValues = {
  output: '',
  threads: 1,
  assembler: assemblerOptions[0],
  downloadUniprot: true,
  check: false
}
