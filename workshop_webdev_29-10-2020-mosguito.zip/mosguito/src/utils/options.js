
export const assemblerOptions = ['metaspades', 'megahit']
